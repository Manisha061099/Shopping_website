<?php
	include 'database.php';
    //$base_url = "http://localhost/shoppingproject-yb/";
     $base_url = "http://localhost/shopping-project/";
    

?>